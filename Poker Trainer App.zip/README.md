
  # Poker Trainer App

  This is a code bundle for Poker Trainer App. The original project is available at https://www.figma.com/design/V2OncGMSBNb9n9EQV8TbCY/Poker-Trainer-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  